export function addList(name, location) {
  return {
    name,
    location,
    type: 'ADD_LIST'
  }
}
